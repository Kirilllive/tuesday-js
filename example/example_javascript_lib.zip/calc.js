function calculation_check(elem) {
    // enter
    let data = elem.innerHTML.split('=')[0];
    let prom = prompt(data, '');
    let next = true
    elem.innerHTML = data+'='+prom;
    // check
    let buttons=tuesday.getElementsByClassName('tue_choice')
    for(let i=0;i<buttons.length;i++){
        if(buttons[i].getAttribute("onclick").includes('calculation_check')){
            data = buttons[i].innerHTML.split('=');
            if(eval(data[0])!=data[1]){next=false}
        }
    }
    if(next){ go_story(true) }
}
