function data_time(){
    var element=document.createElement("div");
    element.id='data_time'
    element.innerHTML = Date();
    element.style='padding:8px;position:absolute;left:50%;top:50%;transform:translateX(-50%) translateY(-50%);background-color:#fff;border-radius:8px;';
    tuesday.appendChild(element);
}
