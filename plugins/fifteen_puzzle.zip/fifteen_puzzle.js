var freeslot=[],size=[],m=[],o,f;
function ceation_slots(){
    arr_dialog=story_json[tue_story][scene].puzzle_fifteen;
    tue_next.style.visibility='hidden';
    f=document.createElement("div");
    f.id="tue_puzzle_fifteen"
    f.innerHTML="<div id='fifteen'></div>"
    f.style="height:100%;width:100%;display:grid;align-content:center;justify-content:center;";
    tuesday.appendChild(f);
    f=document.getElementById("fifteen");
    f.style.width=arr_dialog.size[0]+'px';
    f.style.height=arr_dialog.size[1]+'px';
    f.style.position='relative';
    size=[arr_dialog.size[0]/(arr_dialog.grid[0]+1),arr_dialog.size[1]/(arr_dialog.grid[1]+1)]
    var c=(arr_dialog.grid[1]+1)*(arr_dialog.grid[0]+1)-1;
    if(arr_dialog.fill){fifteen_resize();window.addEventListener('resize',fifteen_resize,true);}
    o=1;
    for(var y=0;y<=arr_dialog.grid[1];y++){
        for(var x=0;x<=arr_dialog.grid[0];x++){
            if(o<=c){
                if(!m[y]){m[y]=[]};m[y][x]=o;
                var e=document.createElement("div");
                e.id="slot"+o;
                e.setAttribute("onclick","move_slot("+o+")");
                e.className="slot";
                if(arr_dialog.number){e.innerHTML=o}
                e.style="background-image:url("+arr_dialog.art.url+");background-size:"+((arr_dialog.art.ratio)? arr_dialog.size[0]+"px auto":"auto "+arr_dialog.size[1]+"px")+";background-position:-"+(size[0]*x)+"px -"+(size[1]*y)+"px ;width:"+size[0]+"px;height:"+size[1]+"px;top:"+(size[1]*y)+"px;left:"+(size[0]*x)+"px;position:absolute;"+((arr_dialog.style)?arr_dialog.style:"")
                if(arr_dialog.time){e.style.transitionDuration=arr_dialog.time+"s"}
                f.appendChild(e);o++;
            }else{m[y][x]=0;freeslot=[arr_dialog.grid[1],arr_dialog.grid[0]];}
        }
    }
    stir_slots();
}
function stir_slots(){
    for(var y=0;y<arr_dialog.diff;y++){
        var a=[];
        if((Math.random()*2)>1){
            a=[freeslot[0]+(-1+Math.round(Math.random()*2)),freeslot[1]];
            if(a[0]<0){a[0]=a[0]+2}else if(a[0]>arr_dialog.grid[1]){a[0]=a[0]-2}
        }else{
            a=[freeslot[0],freeslot[1]+(-1+Math.round(Math.random()*2))];
            if(a[1]<0){a[1]=a[1]+2}else if(a[1]>arr_dialog.grid[0]){a[1]=a[1]-2}
        }
        var s=[m[freeslot[0]][freeslot[1]],m[a[0]][a[1]]]
        m[freeslot[0]][freeslot[1]]=s[1];m[a[0]][a[1]]=s[0]
        freeslot=[a[0],a[1]] 
    }
    for(var y=0;y<=arr_dialog.grid[1];y++){
        for(var x=0;x<=arr_dialog.grid[0];x++){
            if(m[y][x]){
                var e=document.getElementById("slot"+m[y][x])
                e.style.left=(x*size[0])+"px";
                e.style.top =(y*size[1])+"px";
            }
        }
    }
}
function move_slot(s) {
    var z=0,e,a=[],k,j;
    function move(y,x,h,w){
        j=m[y][x]
        e=document.getElementById("slot"+j);
        e.style.left=((x+w)*size[0])+"px";
        e.style.top =((y+h)*size[1])+"px";
        m[y][x]=k;k=j;
    }
    for(var y=0;y<arr_dialog.grid[1]+1;y++){
        for(var x=0;x<arr_dialog.grid[0]+1;x++){
            if(m[y][x]==s){
                a=[y,x];k=0;
                if(freeslot[0]==a[0]){
                    if(freeslot[1]>a[1]){for(z=0;z<freeslot[1]-a[1];z++){move(a[0],a[1]+z,0,+1)}}
                    else if(freeslot[1]<a[1]){for(z=0;z<a[1]-freeslot[1];z++){move(a[0],a[1]-z,0,-1)}}
                    m[freeslot[0]][freeslot[1]]=k;freeslot=[a[0],a[1]];s=false;break;
                }else if(freeslot[1]==a[1]){
                    if(freeslot[0]>a[0]){for(z=0;z<freeslot[0]-a[0];z++){ move(a[0]+z,a[1],+1,0)}}
                    else if(freeslot[0]<a[0]){for(z=0;z<a[0]-freeslot[0];z++){move(a[0]-z,a[1],-1,0)}}
                    m[freeslot[0]][freeslot[1]]=k;freeslot=[a[0],a[1]];s=false;break;
                }
            }if(!s){break;}
        }if(!s){break;}
    }check_slots();
}
function check_slots(){
    var c=1;
    for(var y=0;y<=arr_dialog.grid[1];y++){
        for(var x=0;x<=arr_dialog.grid[0];x++){
            if(m[y][x]==0){break;}
            if(c==m[y][x]){c++}
        }
    }if(c==o){setTimeout(()=>{tue_puzzle_fifteen.remove();go_to(arr_dialog.go_to);},((arr_dialog.time)?arr_dialog.time*1000:0));}
}
function fifteen_resize(){
    var rect=f.parentNode.getBoundingClientRect();
    if((arr_dialog.size[0]/arr_dialog.size[1])<(rect.width/rect.height)){f.style.transform='scale('+(rect.height/arr_dialog.size[1])+')'}
    else{f.style.transform='scale('+(rect.width/arr_dialog.size[0])+')'}
}
tuesday.addEventListener('save', function(event) { toast("save") } );
tuesday.addEventListener('load', function(event) { toast("load") } );
document.addEventListener("keydown",function(e){
    e=e.keyCode;
         if(e==37){move_slot(m[freeslot[0]][freeslot[1]+1]);}
    else if(e==39){move_slot(m[freeslot[0]][freeslot[1]-1]);}
    else if(e==38){move_slot(m[freeslot[0]+1][freeslot[1]]);}
    else if(e==40){move_slot(m[freeslot[0]-1][freeslot[1]]);}
})
tuesday.addEventListener('puzzle_fifteen',function(event){ceation_slots();});
